<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class MediaLibrary extends Model {
	protected $table = 'media_library';
}
