<?php
	$breadcrumb = [];
	$breadcrumb[0]['title'] = 'Dashboard';
	$breadcrumb[0]['url'] = url('backend/dashboard');
	$breadcrumb[1]['title'] = 'General Report';
	$breadcrumb[1]['url'] = url('backend/general-report');
?>

<!-- LAYOUT -->


<!-- TITLE -->
<?php $__env->startSection('title', 'Set Waktu'); ?>

<!-- CONTENT -->
<?php $__env->startSection('content'); ?>
	<div class="page-title">
		<div class="title_left" style="width : 100%">
			<h3>General Report</h3>
		</div>
	</div>
	<div class="clearfix"></div>
	<?php echo $__env->make('backend.elements.breadcrumb',array('breadcrumb' => $breadcrumb), array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<div class="row">
		<div class="col-md-12 col-sm-12 col-xs-12">
			<div class="x_panel">
				<div class="x_content">
                    <?php echo e(Form::open(['url' => 'backend/general-report', 'method' => 'GET','class' => 'form-horizontal'])); ?>

                    <div class="row">
                        <div class="col-xs-12 col-sm-2 text-right" style="margin-top:7px;">
                            User
                        </div>
                        <div class="col-xs-12 col-sm-4">
                            <?php echo e(Form::select(
                                'user',
                                $user,
                                $id_user,
                                array(
                                    'class' => 'form-control',
                                ))); ?>

                        </div>
                    </div>
                    <br/>
                    <div class="row">
                        <div class="col-xs-12 col-sm-2 text-right" style="margin-top:7px;">
                            Tanggal
                        </div>
                        <div class="col-xs-12 col-sm-3 date">
                            <div class='input-group date' id='myDatepicker'>
                                <input type='text' class="form-control" name="startDate" value=<?=$startDate;?> />
                                <span class="input-group-addon">
                                    <span class="glyphicon glyphicon-calendar"></span>
                                </span>
                            </div>
                        </div>
                        <div class="col-xs-12 col-sm-3 date">
                            <div class='input-group date' id='myDatepicker2'>
                                <input type='text' class="form-control" name="endDate" value=<?=$endDate;?> />
                                <span class="input-group-addon">
                                    <span class="glyphicon glyphicon-calendar"></span>
                                </span>
                            </div>
                        </div>
                        <div class="col-xs-12 col-sm-2">
                            <input type="submit" class="btn btn-primary btn-block" value="Submit">
                        </div>
                    </div>
                    <?php echo e(Form::close()); ?>

				</div>
			</div>
		</div>
    </div>
    
    <?php
        if (isset($_GET['startDate'])):
    ?>
    <div class="row">
		<div class="col-md-12 col-sm-12 col-xs-12">
			<div class="x_panel">
				<div class="x_content">
                    <h2>User : <?=$data_user[0]->firstname.' '.$data_user[0]->lastname ?></h2>
                    <div class="row row--flex">
                        <div class="col-xs-12 col-order-1">
                            <h2>Detail</h2>
                            <?php
                                $tanggal = '';
                                $i = 1; 
                                $jam_kosong = 0;
                                $jam_akhir = 0;
                                $jam_kerja = 0;
                                foreach ($data_workbook as $workbook):
                            ?>
                                <?php
                                    $jam_kerja = $jam_kerja + strtotime($workbook->akhir) - strtotime($workbook->awal);
                                    if (($i > 1) && ($tanggal <> $workbook->tanggal)){
                                        echo "<hr/>";
                                        $jam_akhir = 0;
                                        $i = 1;
                                    }
                                    if (($i > 1) && ($tanggal = $workbook->tanggal)){
                                        if (strtotime($workbook->awal) - strtotime($jam_akhir) >= 0){
                                            $jam_kosong = $jam_kosong + strtotime($workbook->awal) - strtotime($jam_akhir);
                                        }
                                    }
                                ?>
                                <br/>
                                <div class="row">
                                    <div class="col-xs-12 col-sm-3">
                                        <?=date('d M Y', strtotime($workbook->tanggal));?>
                                    </div>
                                    <div class="col-xs-12 col-sm-3">
                                        <?=date('H:i', strtotime($workbook->awal));?> - <?=date('H:i', strtotime($workbook->akhir));?>
                                    </div>
                                    <div class="col-xs-12 col-sm-2">
                                        <?=$workbook->requester;?>
                                    </div>
                                    <div class="col-xs-12 col-sm-4">
                                        <?=nl2br($workbook->keterangan);?>
                                    </div>
                                </div>
                            <?php
                                    $tanggal = $workbook->tanggal;
                                    $jam_akhir = $workbook->akhir;
                                    $i++;
                                endforeach;
                            ?>
                        </div>
                        <div class="col-xs-12">
                            <div class="row">
                                <div class="col-xs-12">
                                    <h4>Durasi Kerja (Jam) : <?=number_format($jam_kerja / 3600, 2,',','.');?></h4>
                                    <h4>Durasi Kosong (Jam) : <?=number_format($jam_kosong / 3600, 2,',','.');?></h4>
                                </div>
                            </div>
                            <hr>
                            <div class="row">
                                <div class="col-xs-12 col-sm-4">
                                    <canvas id="pieChartR"></canvas>
                                </div>
                            </div>
                            <hr>
                        </div>
                    </div>
				</div>
			</div>
		</div>
    </div>
    <?php
        endif;
    ?>
<?php $__env->stopSection(); ?>

<!-- CSS -->
<?php $__env->startSection('css'); ?>
    <style>
        .row--flex {
            display: flex;
            flex-wrap: wrap;
        }
        .col-order-1 {
            order: 1;
        }
    </style>
<?php $__env->stopSection(); ?>

<!-- JAVASCRIPT -->
<?php $__env->startSection('script'); ?>
    <!-- Chart.js -->
    <script src="<?=url('vendors/Chart.js/dist/Chart.min.js');?>"></script>
    <script>
        $('.date').datetimepicker({
            format: 'DD-MM-YYYY',
        });
    </script>
    <?php
        if (isset($_GET['startDate'])):
    ?>
    <script>
        var ctx = document.getElementById("pieChartR").getContext('2d');
        var myChart = new Chart(ctx, {
            type: 'doughnut',
                data: {
                    datasets: [{
                        data: [<?=$jam_kerja / 60;?>, <?=$jam_kosong / 60;?>],
                        backgroundColor: [
                            'rgba(255, 99, 132, 1)',
                            'rgba(54, 162, 235, 1)'
                        ],
                        label: 'Dataset 1'
                    }],
                    labels: [
                        'Durasi Kerja',
                        'Durasi Kosong'
                    ]
                },
                options: {
                    legend: {
                        position: 'top',
                    },
                    title: {
                        display: false,
                        text: 'Chart.js Doughnut Chart'
                    },
                    animation: {
                        animateScale: true,
                        animateRotate: true
                    }
                }
        });
    </script>
    <?php
        endif;
    ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>