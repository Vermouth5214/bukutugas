<?php if(Session::has('success')): ?>
    <div class="row">
	    <div class="col-xs-12 alert alert-<?=Session::get('mode');?> alert-dismissible" role="alert">
		    <?php echo e(Session::get('success')); ?> <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
        </div>
    </div>
<?php endif; ?>