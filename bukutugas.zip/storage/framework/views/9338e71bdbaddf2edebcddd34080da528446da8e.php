<?php
	$breadcrumb = [];
	$breadcrumb[0]['title'] = 'Dashboard';
	$breadcrumb[0]['url'] = url('backend/dashboard');
?>

<!-- LAYOUT -->


<!-- TITLE -->
<?php $__env->startSection('title', 'Dashboard'); ?>

<!-- CONTENT -->
<?php $__env->startSection('content'); ?>
    <div class="page-title">
        <div class="title_left">
            <h3>Dashboard</h3>
        </div>
        <div class="title_right">
        </div>
    </div>
    <div class="clearfix"></div>
    <?php echo $__env->make('backend.elements.breadcrumb',array('breadcrumb' => $breadcrumb), array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>	
    <div class="row">
        <div class="col-xs-12">
            
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>