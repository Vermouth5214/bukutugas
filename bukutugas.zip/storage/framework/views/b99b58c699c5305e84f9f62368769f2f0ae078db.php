<?php
	$breadcrumb = [];
	$breadcrumb[0]['title'] = 'Dashboard';
	$breadcrumb[0]['url'] = url('backend/dashboard');
	$breadcrumb[1]['title'] = 'User Level';
	$breadcrumb[1]['url'] = url('backend/users-level');
?>

<!-- LAYOUT -->


<!-- TITLE -->
<?php $__env->startSection('title', 'Master User Level'); ?>

<!-- CONTENT -->
<?php $__env->startSection('content'); ?>
	<div class="page-title">
		<div class="title_left">
			<h3>Master User Level</h3>
		</div>
		<div class="title_right">
			<div class="col-md-4 col-sm-4 col-xs-8 form-group pull-right top_search">
				<?php echo $__env->make('backend.elements.create_button',array('url' => '/backend/users-level/create'), array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			</div>
		</div>
	</div>
	<div class="clearfix"></div>
	<?php echo $__env->make('backend.elements.breadcrumb',array('breadcrumb' => $breadcrumb), array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>	
	<div class="row">
		<div class="col-xs-12">
			<div class="x_panel">
				<div class="x_content">
					<?php echo $__env->make('backend.elements.notification', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    <table class="table table-striped table-hover table-bordered dt-responsive nowrap dataTable" cellspacing="0" width="100%">
						<thead>
							<tr>
								<th>ID</th>
								<th>Level</th>
								<th>Status</th>
								<th>Actions</th>
							</tr>
						</thead>
					</table>
				</div>
			</div>
		</div>					
	</div>
<?php $__env->stopSection(); ?>

<!-- CSS -->
<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>

<!-- JAVASCRIPT -->
<?php $__env->startSection('script'); ?>
	<script>
		$('.dataTable').dataTable({
			processing: true,
			serverSide: true,
			ajax: "<?=url('backend/users-level/datatable');?>",
			columns: [
				{data: 'id', name: 'id'},
				{data: 'name', name: 'name'},
				{data:  'active', render: function ( data, type, row ) {
					var text = "";
					var label = "";
					if (data == 1){
						text = "Active";
						label = "success";
					} else 
					if (data == 2){
						text = "Deactive";
						label = "warning";
					}
					return "<span class='badge badge-" + label + "'>"+ text + "</span>";
                }},				
				{data: 'action', name: 'action', orderable: false, searchable: false}
			],
			responsive: true
		});
	</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>