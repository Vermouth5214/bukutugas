<footer>
	<div class="pull-right">
		© 2019 <b>Version</b> 1.0.0 <strong>All rights reserved</strong> | Gentelella - Bootstrap Admin Template by <a href="https://colorlib.com">Colorlib</a>
	</div>  
	<div class="clearfix"></div>
</footer>