<a href="<?=url($url);?>" class="btn-index btn btn-primary btn-block" title="Back"><i class="fa fa-arrow-left"></i>&nbsp; Back</a>
